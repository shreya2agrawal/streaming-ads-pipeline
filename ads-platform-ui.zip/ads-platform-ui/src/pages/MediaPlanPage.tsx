import React from 'react';
export default function MediaPlanPage() {
  return <div style={{ padding: 24, color: '#e5e5e5' }}>Media Plans — coming soon</div>;
}