import React from 'react';
export default function InventoryPage() {
  return <div style={{ padding: 24, color: '#e5e5e5' }}>Inventory — coming soon</div>;
}